from exceptions import SerializationError
import string
import urllib

def __marshal_string(py_string):
    ret = ''
    complex = ["%", ",", "{", "}"]
    simple = ['!','\"','#','$','&','\'','(',')','*','+','-','.','/',':',';','<','=','>','?','@','[',']','^','_','`','|','~', ' ']
    # TODO: Validate and encode
    per = urllib.parse.quote(py_string)
    if all(s.isprintable() for s in py_string) and not(any(x in py_string for x in complex) or "\\" in r"%r" % py_string):
        ret = py_string + 's'
    else:
        ret = per
    #raise SerializationError('string is not simple or complex')
    return ret

def __marshal_integer(py_int):
    ret = ''
    # TODO: Validate and encode
    
    ret = 'i' + str(py_int)
    return ret

def __marshal_map(py_dict):
    ret = ''
    counter = 0
    for key, value in py_dict.items():
        # TODO: Validate, dispatch, and combine
        if (not isinstance(key, str) or not any(k in key for k in string.ascii_letters + string.digits + " " + "-" + "_" + "+" + ".")):
            raise SerializationError('key is not a string or does not contain at one of required characters')
        if (type(value) != str and type(value) != dict and type(value) != int):
            raise SerializationError('value is not an allowed data type')
        if (value == None or key == None):
            raise SerializationError('value or key is null')
        if (value == '' or key == ''):
            raise SerializationError('value or key is an empty string')        
        if type(value) == dict:
            if counter > 0:
                ret += "," + key + ":" + __marshal_map(value)
            else:
                ret += key + ":" + __marshal_map(value)
        if type(value) == str:
            ret_string = __marshal_string(value)
            if counter > 0:
                ret += ',' + key + ":" + ret_string
            else:
                ret += key + ":" + ret_string
        elif type(value) == int:
            ret_int = __marshal_integer(value)
            if counter > 0:
                ret += ',' + key + ":" + ret_int
            else:
                ret += key + ":" + ret_int
        counter+=1
    ret = '{' + ret
    ret += '}'
    return ret

def marshal(unmarshalled_state):
    if unmarshalled_state is None:
        raise SerializationError('Input is None')
    if type(unmarshalled_state) != dict:
        raise SerializationError('Input is not a dict')

    # TODO: Validate things about the overall Python3 dict

    return __marshal_map(unmarshalled_state)
