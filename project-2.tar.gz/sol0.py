import sys

nullPad = b'\0\0\0'
data = b'wva0001' 
data += nullPad
data += b'A+'
sys.stdout.buffer.write(data)
